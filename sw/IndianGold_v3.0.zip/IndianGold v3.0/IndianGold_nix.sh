#!/bin/sh
FNAME="`readlink -f .`"
cd "$FNAME"
java -jar IndianGold.jar
exit 0
